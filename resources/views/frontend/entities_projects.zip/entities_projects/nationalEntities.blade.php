@extends('frontend.layout.main', ['title' => 'National Entities', 'header' => 'National Entities'])
@section('content')
        <div class="container">
            <p class="alert text-alert">National ICT Entities</p>
        </div>
@endsection
@push('after-scripts')
@endpush

@push('after-styles')
@endpush